# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# This file is in the public domain
### END LICENSE

from locale import gettext as _
import subprocess 
import os 
import sys

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('hack_the_drone')

from hack_the_drone_lib import Window
from hack_the_drone.AboutHackTheDroneDialog import AboutHackTheDroneDialog
from hack_the_drone.PreferencesHackTheDroneDialog import PreferencesHackTheDroneDialog

# See hack_the_drone_lib.Window.py for more details about how this class works
class HackTheDroneWindow(Window):
    __gtype_name__ = "HackTheDroneWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(HackTheDroneWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutHackTheDroneDialog
        self.PreferencesDialog = PreferencesHackTheDroneDialog

        # Code for other initialization actions should be added here.

        self.button1 = self.builder.get_object("button1")
        self.button2 = self.builder.get_object("button2")
        self.button3 = self.builder.get_object("button3")

    def on_button1_clicked( self , widget ) : 
        #subprocess.call(['sh','./sample.sh'])
        #subprocess.call(["./sample.sh"])
        os.system("sh sample.sh") 

    def on_button2_clicked( self , widget ) : 
        subprocess.call(['sh','./MissionPlanner.sh'])

    def on_button3_clicked( self , widget ) : 
        subprocess.call(['sh','./fuzzer.sh'])

